aws glue start-job-run --job-name "bug_n" --arguments='--s3_bucket="aws-isgaur-logs",--config="test.ini",--password="test"'
