aws sts decode-authorization-message --encoded-message <encoded_msg>
