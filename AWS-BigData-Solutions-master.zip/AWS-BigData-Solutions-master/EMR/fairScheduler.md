https://medium.com/@sohamghosh/schedulers-in-emr-6445180b44f6
