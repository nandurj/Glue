install pip
$ curl -O https://bootstrap.pypa.io/get-pip.py

$ python get-pip.py --user

or

python3 get-pip.py --user

Install parquet cli tools 

pip install parquet-cli --user


parq -h


parq LOAD00000001.parquet -s
