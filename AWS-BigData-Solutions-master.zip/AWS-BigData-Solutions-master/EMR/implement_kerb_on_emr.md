https://medium.com/@neerajsabharwal/how-to-implement-kerberos-in-aws-emr-f56594467bd
