https://tokern.io/blog/lake-formation-permissions/
