aws cloudformation create-stack --template-body file:///Users/abc/Documents/isemr.json --stack-name ddd --capabilities CAPABILITY_NAMED_IAM

