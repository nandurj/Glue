hive --hiveconf hive.root.logger=DEBUG,console
