Customers shouldn't use two connections unless they have a security group need. 

If they are different subnets, it causes confusion in the connection since it will only use one of them and its unpredictable which one will be chosen for network provisioning stage. 

And if they are both in the same subnet, what is the point. Single subnet to simplify things. 
