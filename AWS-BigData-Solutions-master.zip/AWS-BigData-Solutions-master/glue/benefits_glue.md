Speed Of implementation
Less code to Mantain < 10 lines versus 200 + lines for array attributes.
Less overhead for Operations team within an Org.
Performance for DDB significantly better using AWS glue - about 10X
Solve for patterns - deeply nested jsons , arrays 
makes data easy to query 
Generalised ETL process 
No cluster management
