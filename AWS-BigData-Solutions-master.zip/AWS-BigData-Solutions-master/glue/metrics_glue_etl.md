glue.driver.jvm.heap.used

glue.executorId.jvm.heap.used

glue.ALL.jvm.heap.used

glue.driver.jvm.heap.usage

glue.executorId.jvm.heap.usage

glue.ALL.jvm.heap.usage

glue.driver.aggregate.bytesRead

glue.driver.aggregate.numFailedTasks

glue.driver.aggregate.shuffleBytesWritten

glue.driver.aggregate.shuffleLocalBytesRead

glue.driver.BlockManager.disk.diskSpaceUsed_MB

glue.driver.ExecutorAllocationManager.executors.numberAllExecutors

glue.driver.ExecutorAllocationManager.executors.numberMaxNeededExecutors

glue.driver.s3.filesystem.read_bytes

glue.executorId.s3.filesystem.read_bytes

glue.ALL.s3.filesystem.read_bytes

glue.driver.s3.filesystem.write_bytes

glue.executorId.s3.filesystem.write_bytes

glue.ALL.s3.filesystem.write_bytes

glue.driver.system.cpuSystemLoad

glue.executorId.system.cpuSystemLoad

glue.ALL.system.cpuSystemLoad


















