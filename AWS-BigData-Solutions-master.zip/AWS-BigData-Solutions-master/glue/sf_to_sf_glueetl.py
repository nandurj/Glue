import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from py4j.java_gateway import java_import
from awsglue import DynamicFrame
import boto3
import botocore
SNOWFLAKE_SOURCE_NAME = "net.snowflake.spark.snowflake";

## @params: [JOB_NAME, URL, ACCOUNT, WAREHOUSE, DB, SCHEMA, USERNAME, PASSWORD]
# args = getResolvedOptions(sys.argv, ['JOB_NAME', 'URL', 'ACCOUNT', 'WAREHOUSE', 'DB', 'SCHEMA', 'USERNAME', 'PASSWORD'])
sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

job = Job(glueContext)
job.init('Connection Test')
java_import(spark._jvm, "net.snowflake.spark.snowflake")

s3 = boto3.resource('s3')
query = s3.Object('your-s3-bucket', 'sql_scripts/your_sql_script_name.sql').get()['Body'].read().decode("utf-8").format(arg_1='2022-04-01', arg_2='1', arg_3='CAT')
print(query)



spark._jvm.net.snowflake.spark.snowflake.SnowflakeConnectorUtils.enablePushdownSession(spark._jvm.org.apache.spark.sql.SparkSession.builder().getOrCreate())
sfOptions = {
"sfURL" : '********',
"sfAccount" : '********',
"sfUser" : '********',
"sfPassword" : '********',
"sfDatabase" : 'database-name',
"sfSchema" : 'schema-name',
"sfWarehouse" : 'warehouse-name',
"sfRole": 'snowflake-role'
}

## Read from a Snowflake table into a Spark Data Frame
# df = spark.read.format(SNOWFLAKE_SOURCE_NAME).options(**sfOptions).option("dbtable", "AGREEMENT").load()
df_query = spark.read.format(SNOWFLAKE_SOURCE_NAME).options(**sfOptions).option("query", query).load()
# df.show(10)
df_query.show(10)

## Perform any kind of transformations on your data and save as a new Data Frame: df1 = df.[Insert any filter, transformation, or other operation]
## Write the Data Frame contents back to Snowflake in a new table df1.write.format(SNOWFLAKE_SOURCE_NAME).options(**sfOptions).option("dbtable", "[new_table_name]").mode("overwrite").save() job.commit()
job.commit()
