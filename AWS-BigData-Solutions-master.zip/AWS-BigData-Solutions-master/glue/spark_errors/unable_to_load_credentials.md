========================
import os
os.environ["AWS_METADATA_SERVICE_TIMEOUT"] = "10"
os.environ["AWS_METADATA_SERVICE_NUM_ATTEMPTS"] = "50"
========================
