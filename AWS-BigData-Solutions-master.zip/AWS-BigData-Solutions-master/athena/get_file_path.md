SELECT *,"$path" FROM "my_database"."my_table" on original source table 
